package com.dx.jwfm.framework.core.model;

public class FastModelUpdateLog {

}
