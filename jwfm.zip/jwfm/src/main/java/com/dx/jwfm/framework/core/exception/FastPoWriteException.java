package com.dx.jwfm.framework.core.exception;

public class FastPoWriteException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public FastPoWriteException(String msg){
		super(msg);
	}
}
