package com.dx.jwfm.framework.core.dao.model;

public enum FastColumnType {
	
	 String//字符串
	,Integer
	,Long
	,Float
	,Double
	,Date//日期+时间
}
